/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   name.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amordret <amordret@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/09 14:58:44 by amordret          #+#    #+#             */
/*   Updated: 2018/08/09 14:58:44 by amordret         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "raspi.h"

int		checkid(char *id)
{
	int i;

	i = 0;
	while (id[i])
	{
		if (!(id[i] > 47 && id[i] < 58))
			return (0);
			i++;
	}
	return (0);
}

char	*whatsmyname(char *id)
{
	char	*name;
	int		pipeu[2];
	char	**av;
	pid_t	pid;
	char	c;
	int		i;

	i = 0;
	name = malloc(50);
	av = malloc(sizeof(*av) * 4);
	if (!id)
		return (NULL);
	av[0] = ft_strdup(AV0);
	av[1] = ft_strdup("-sd");
	av[2] = malloc(57);
	ft_strncpy(av[2], "auth=9d9148c0b1da81c605a6d38ae6f6ef2c&rfid=", 55);
	ft_strcat(av[2], id);
	av[3] = ft_strdup("http://labelec-api.42.fr:8092/whois");
	av[4] = NULL;
	if (pipe(pipeu) == -1)
	{
		strcpy(name, "PIPE ERROR");
		return (name);
	}
	if ((pid = fork()) == -1)
	{
		strcpy(name, "FORK ERROR");
		return (name);
	}
	if (pid == 0)
	{
		//fils
		dup2 (pipeu[1], STDOUT_FILENO);
    	close(pipeu[0]);
    	//close(pipeu[1]);
		execve(AV0, av, NULL);
	}
	else
	{
		//pere
		close(pipeu[1]);
		c = 'a';
		while (i < 49 && c != '\0' && c != '\n')
		{
			if ((read(pipeu[0], &c, 1)) == 0)
				break ;
			name[i] = c;
			i++;
			if (c == '\0' || c == '\n')
				break ;
			//wait(NULL);
		}
		name[i] = '\0';
		free(av[0]);
		free(av[1]);
		free(av[2]);
		free(av[3]);
		free(av);
		wait(NULL);
	}
	return (name);
}
